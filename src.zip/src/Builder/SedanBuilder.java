package Builder;

// Concrete builders
public class SedanBuilder implements CarBuilder {
    private Car car;

    public SedanBuilder() {
        car = new Car("Unknown", "Unknown", 0, "Unknown");
    }

    @Override
    public CarBuilder setMake(String make) {
        car.make = make;
        return this;
    }

    @Override
    public CarBuilder setModel(String model) {
        car.model = model;
        return this;
    }

    @Override
    public CarBuilder setYear(int year) {
        car.year = year;
        return this;
    }

    @Override
    public CarBuilder setColor(String color) {
        car.color = color;
        return this;
    }

    // Specific methods for SedanBuilder

    public SedanBuilder setSunroof(boolean hasSunroof) {
        // Set sunroof property
        return this;
    }

    @Override
    public Car build() {
        return car;
    }
}

package Builder;

public class SportsCarBuilder implements CarBuilder {
    private Car car;

    public SportsCarBuilder() {
        car = new Car("Unknown", "Unknown", 0, "Unknown");
    }

    @Override
    public CarBuilder setMake(String make) {
        car.make = make;
        return this;
    }

    @Override
    public CarBuilder setModel(String model) {
        car.model = model;
        return this;
    }

    @Override
    public CarBuilder setYear(int year) {
        car.year = year;
        return this;
    }

    @Override
    public CarBuilder setColor(String color) {
        car.color = color;
        return this;
    }

    // Specific methods for SportsCarBuilder

    public SportsCarBuilder setSpoiler(boolean hasSpoiler) {
        // Set spoiler property
        return this;
    }

    @Override
    public Car build() {
        return car;
    }
}


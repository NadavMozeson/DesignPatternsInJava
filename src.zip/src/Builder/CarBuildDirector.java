package Builder;

// Director class
public class CarBuildDirector {
    private CarBuilder carBuilder;

    public CarBuildDirector(CarBuilder carBuilder) {
        this.carBuilder = carBuilder;
    }

    public Car constructCar() {
        return carBuilder.setMake("Ford")
                .setModel("Mustang")
                .setYear(2022)
                .setColor("Red")
                .build();
    }
}

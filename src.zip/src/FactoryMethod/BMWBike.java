package FactoryMethod;

public class BMWBike implements Bike  {
    private int numOfWeels;
    private int numOfPass;
    private int life;
    public  BMWBike(int tempNumOfWeels, int tempNumOfPass, int tempLife){
        this.numOfWeels = tempNumOfWeels;
        this.numOfPass = tempNumOfPass;
        this.life = tempLife;
    }
    @Override
    public void turnOn() {
        System.out.println("Turned On BMW Bike");
    }

    public int getNumOfWeels() {
        return numOfWeels;
    }

    public void setNumOfWeels(int numOfWeels) {
        this.numOfWeels = numOfWeels;
    }

    public int getNumOfPass() {
        return numOfPass;
    }

    public void setNumOfPass(int numOfPass) {
        this.numOfPass = numOfPass;
    }

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }
}

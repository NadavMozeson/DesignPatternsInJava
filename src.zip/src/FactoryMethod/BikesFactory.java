package FactoryMethod;

public class BikesFactory implements Factory{
    public Vehicle getVehicle(String name){
        if(name.equals("BMW")){
            return new BMWBike(4,2,5);
        } else if (name.equals("Audi")) {
            return new AudiBike();
        }
        return null;
    }
}

package FactoryMethod;

public interface Vehicle {
    void turnOn();
}

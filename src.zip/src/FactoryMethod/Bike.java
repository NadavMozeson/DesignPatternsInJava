package FactoryMethod;

public interface Bike extends Vehicle {
}

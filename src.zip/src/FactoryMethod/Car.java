package FactoryMethod;

public interface Car extends Vehicle{
}

package FactoryMethod;

public interface Factory {
    Vehicle getVehicle(String name);
}

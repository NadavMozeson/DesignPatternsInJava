public class TestThread extends Thread {
    public void run() {
        Test.getInstance().threadRunning();
    }
}

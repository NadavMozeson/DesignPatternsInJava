public class Test {
    private static Test instance;

    private Test(){
    }

    public static Test getInstance() {
        if(instance == null){
            instance = new Test();
        }
        return instance;
    }

    public void threadRunning() {
        float random = (float) (Math.random() * ((10 - 1) + 1)) + 1;
        int delay = (int) random * 1000;
        for (int i = 1; i <= 5; i++) {
            synchronized (System.out) {
                System.out.println("Thread " + i + "");
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public void testPrint(){
        for (int i = 1; i <= 5; i++) {
            System.out.print("Hello World!");
        }
    }
}
